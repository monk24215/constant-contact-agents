// server.js — Constant Contact COMPOSER (single-file).
// Reads the Notion "Email Campaign Calendar", finds rows at Pipeline="Ready to
// Build", creates DRAFT email campaigns in Constant Contact in the Defend
// Survive Prepare house style, writes the campaign id/link back to Notion, and
// advances the row to "Drafted in CC".
//
// DRAFT-ONLY. This service has no send or schedule capability, by design.
//
// Everything is inlined here so there is exactly one file to deploy.

import express from 'express';
import pg from 'pg';

const { Pool } = pg;

// ---------------------------------------------------------------------------
// Config / env
// ---------------------------------------------------------------------------
const PORT = process.env.PORT || 3000;
const POLL_MINUTES = Number(process.env.POLL_MINUTES || 15);
const CC_AUTHZ = 'https://authz.constantcontact.com/oauth2/default/v1';
const CC_API = process.env.CONSTANT_CONTACT_BASE_URL || 'https://api.cc.email/v3';
const NOTION_BASE = 'https://api.notion.com/v1';
const NOTION_VERSION = '2022-06-28';

function need(name) {
  const v = process.env[name];
  if (!v) throw new Error(`Missing env var: ${name}`);
  return v;
}

// ---------------------------------------------------------------------------
// Token store (Postgres) — shared with the auth service via the same DB
// ---------------------------------------------------------------------------
let pool;
function getPool() {
  if (!pool) pool = new Pool({ connectionString: need('DATABASE_URL') });
  return pool;
}
async function initTokenStore() {
  await getPool().query(`
    CREATE TABLE IF NOT EXISTS oauth_tokens (
      provider TEXT PRIMARY KEY,
      access_token TEXT NOT NULL,
      refresh_token TEXT NOT NULL,
      expires_at TIMESTAMPTZ NOT NULL,
      scope TEXT,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
    );`);
}
async function loadTokens(provider = 'constant_contact') {
  const { rows } = await getPool().query(
    'SELECT access_token, refresh_token, expires_at, scope FROM oauth_tokens WHERE provider=$1',
    [provider]
  );
  return rows[0] || null;
}
async function saveTokens({ accessToken, refreshToken, expiresInSeconds, scope }, provider = 'constant_contact') {
  const expiresAt = new Date(Date.now() + expiresInSeconds * 1000);
  await getPool().query(
    `INSERT INTO oauth_tokens (provider, access_token, refresh_token, expires_at, scope, updated_at)
     VALUES ($1,$2,$3,$4,$5,now())
     ON CONFLICT (provider) DO UPDATE SET
       access_token=EXCLUDED.access_token, refresh_token=EXCLUDED.refresh_token,
       expires_at=EXCLUDED.expires_at, scope=EXCLUDED.scope, updated_at=now()`,
    [provider, accessToken, refreshToken, expiresAt, scope || null]
  );
}

// ---------------------------------------------------------------------------
// OAuth — refresh (rotating) and provide a valid access token
// ---------------------------------------------------------------------------
function basicAuth() {
  return 'Basic ' + Buffer.from(`${need('CC_CLIENT_ID')}:${need('CC_CLIENT_SECRET')}`).toString('base64');
}
async function refreshAccessToken() {
  const stored = await loadTokens();
  if (!stored) throw new Error('No stored tokens. Authorize via the auth service first.');
  const body = new URLSearchParams({ refresh_token: stored.refresh_token, grant_type: 'refresh_token' });
  const res = await fetch(`${CC_AUTHZ}/token`, {
    method: 'POST',
    headers: { Authorization: basicAuth(), 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
    body,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(`Token refresh failed (${res.status}): ${JSON.stringify(data)}`);
  await saveTokens({
    accessToken: data.access_token,
    refreshToken: data.refresh_token || stored.refresh_token,
    expiresInSeconds: data.expires_in,
    scope: data.scope || stored.scope,
  });
  return data.access_token;
}
async function getValidAccessToken() {
  const stored = await loadTokens();
  if (!stored) throw new Error('No stored tokens. Authorize via the auth service first.');
  const expiresAt = new Date(stored.expires_at).getTime();
  if (Date.now() >= expiresAt - 5 * 60 * 1000) return refreshAccessToken();
  return stored.access_token;
}

// ---------------------------------------------------------------------------
// Constant Contact API — create draft campaign
// ---------------------------------------------------------------------------
async function ccFetch(path, { method = 'GET', body } = {}) {
  const token = await getValidAccessToken();
  const res = await fetch(`${CC_API}${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
      ...(body ? { 'Content-Type': 'application/json' } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) throw new Error(`CC ${method} ${path} (${res.status}): ${JSON.stringify(data)}`);
  return data;
}
function physicalAddress() {
  return {
    address_line1: process.env.CC_ADDR_LINE1 || '760 Farm to Market 1626',
    city: process.env.CC_ADDR_CITY || 'Manchaca',
    state_code: process.env.CC_ADDR_STATE || 'TX',
    postal_code: process.env.CC_ADDR_POSTAL || '78652',
    country_code: process.env.CC_ADDR_COUNTRY || 'US',
    organization_name: process.env.CC_ADDR_ORG || 'Defend Survive Prepare',
  };
}
function createDraftCampaign({ name, subject, html }) {
  const fromEmail = need('CC_FROM_EMAIL');
  const fromName = process.env.CC_FROM_NAME || process.env.BRAND_NAME || 'Survival';
  return ccFetch('/emails', {
    method: 'POST',
    body: {
      name,
      email_campaign_activities: [{
        format_type: 5,
        from_name: fromName,
        from_email: fromEmail,
        reply_to_email: process.env.CC_REPLY_TO || fromEmail,
        subject,
        html_content: html,
        physical_address_in_footer: physicalAddress(),
      }],
    },
  });
}

// ---------------------------------------------------------------------------
// House-style HTML template (Defend Survive Prepare)
// ---------------------------------------------------------------------------
function esc(s) { return String(s).replace(/[&<>]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c])); }
function bodyToHtml(body) {
  if (/<[a-z][\s\S]*>/i.test(body)) return body;
  const P = 'text-align:left;margin:0;';
  const SPAN = 'font-size:17px;font-family:Roboto,sans-serif;';
  return body.split(/\n/).map((line) =>
    line.trim() === ''
      ? `<p style="${P}" align="left"><br></p>`
      : `<p style="${P}" align="left"><span style="${SPAN}">${esc(line)}</span></p>`
  ).join('\n');
}
function renderEmailHtml({ subject, body, preheader }) {
  const org = process.env.CC_ADDR_ORG || 'Defend Survive Prepare';
  const line1 = process.env.CC_ADDR_LINE1 || '760 Farm to Market 1626';
  const city = process.env.CC_ADDR_CITY || 'Manchaca';
  const state = process.env.CC_ADDR_STATE || 'TX';
  const postal = process.env.CC_ADDR_POSTAL || '78652';
  const inner = bodyToHtml(body || '');
  return `<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en-US"><head>
<title>${esc(subject || org)}</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"></head>
<body style="margin:0;padding:0;min-width:100%;width:100%;background-color:#474747;">
<div id="preheader" style="color:transparent;display:none;font-size:1px;line-height:1px;max-height:0;max-width:0;opacity:0;overflow:hidden;">${esc(preheader || '')}</div>
[[trackingImage]]
<table width="100%" border="0" cellpadding="0" cellspacing="0" style="background-color:#474747;"><tbody>
<tr><td align="center" valign="top" style="background-color:#ffffff;" bgcolor="#ffffff">
  <table align="center" border="0" cellpadding="0" cellspacing="0" style="width:650px;"><tbody>
  <tr><td align="center" valign="top" style="padding:15px 18px;">
    <table width="100%" align="center" border="0" cellpadding="0" cellspacing="0"><tbody>
    <tr><td align="center" valign="top" style="background-color:#FFFFFF;padding:0;">
      <table width="100%" border="0" cellpadding="0" cellspacing="0"><tbody>
      <tr><td align="center" valign="top" style="width:100%;">
        <div style="height:30px;line-height:30px;">&hairsp;</div>
        <table width="100%" border="0" cellpadding="0" cellspacing="0"><tbody><tr><td style="padding:4px;">
          <table width="100%" border="0" cellpadding="0" cellspacing="0" style="table-layout:fixed;"><tbody>
          <tr><td align="center" valign="top" style="line-height:2;text-align:center;font-family:Roboto,sans-serif;color:#3E3E3E;font-size:17px;display:block;word-wrap:break-word;padding:20px 30px 50px;">
${inner}
          </td></tr></tbody></table>
        </td></tr></tbody></table>
        <div style="height:30px;line-height:30px;">&hairsp;</div>
      </td></tr></tbody></table>
    </td></tr></tbody></table>
  </td></tr></tbody></table>
</td></tr>
<tr><td align="center" valign="top" style="background-color:#FFFFFF;" bgcolor="#FFFFFF">
  <table align="center" border="0" cellpadding="0" cellspacing="0" style="width:700px;"><tbody>
  <tr><td align="center" valign="top" style="padding:0 10px;">
    <table width="100%" align="center" border="0" cellpadding="0" cellspacing="0"><tbody>
    <tr><td align="center" style="color:#595959;font-family:Verdana,Geneva,sans-serif;font-size:12px;line-height:1.2;padding:10px 40px;">
      <p style="margin:0;">${esc(org)} | ${esc(line1)} | ${esc(city)}, ${esc(state)} ${esc(postal)} US</p>
    </td></tr>
    <tr><td align="center" style="color:#595959;font-family:Verdana,Geneva,sans-serif;font-size:12px;line-height:1.2;padding:10px 40px;">
      <p style="margin:0;">[[UNSUBSCRIBE_LINK]] | [[UPDATE_PROFILE_LINK]]</p>
    </td></tr>
    </tbody></table>
  </td></tr></tbody></table>
</td></tr>
</tbody></table>
</body></html>`;
}

// ---------------------------------------------------------------------------
// Notion — read calendar rows, write back
// ---------------------------------------------------------------------------
async function notionFetch(path, { method = 'GET', body } = {}) {
  const res = await fetch(`${NOTION_BASE}${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${need('NOTION_TOKEN')}`,
      'Notion-Version': NOTION_VERSION,
      'Content-Type': 'application/json',
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  const data = text ? JSON.parse(text) : null;
  if (!res.ok) throw new Error(`Notion ${method} ${path} (${res.status}): ${JSON.stringify(data)}`);
  return data;
}
function plain(prop) {
  if (!prop) return '';
  const arr = prop.title || prop.rich_text || [];
  return arr.map((t) => t.plain_text).join('');
}
function sel(prop) { return prop && prop.select ? prop.select.name : null; }

async function getRowsByStage(stage) {
  const data = await notionFetch(`/databases/${need('NOTION_DB_ID')}/query`, {
    method: 'POST',
    body: { filter: { property: 'Pipeline', select: { equals: stage } } },
  });
  return (data.results || []).map((p) => ({
    id: p.id,
    url: p.url,
    name: plain(p.properties['Name']),
    subject: plain(p.properties['Subject']),
    preheader: plain(p.properties['Preheader']),
    body: plain(p.properties['Body']),
    audience: sel(p.properties['Audience']),
  }));
}
async function updateRow(pageId, props) {
  const properties = {};
  if (props.pipeline) properties['Pipeline'] = { select: { name: props.pipeline } };
  if (props.ccCampaignId !== undefined) properties['CC Campaign ID'] = { rich_text: [{ text: { content: String(props.ccCampaignId) } }] };
  if (props.ccActivityId !== undefined) properties['CC Activity ID'] = { rich_text: [{ text: { content: String(props.ccActivityId) } }] };
  if (props.ccLink !== undefined) properties['CC Link'] = { url: props.ccLink || null };
  if (props.notes !== undefined) properties['Agent Notes'] = { rich_text: [{ text: { content: String(props.notes).slice(0, 1900) } }] };
  return notionFetch(`/pages/${pageId}`, { method: 'PATCH', body: { properties } });
}

// ---------------------------------------------------------------------------
// The composer run — DRAFT ONLY
// ---------------------------------------------------------------------------
const DRAFT_ONLY = true;
async function composeOne(row) {
  const subject = row.subject || row.name || 'Newsletter';
  const html = renderEmailHtml({ subject, body: row.body || '', preheader: row.preheader || '' });
  const uniqueName = `${row.name || subject} [${new Date().toISOString().slice(0, 16)}]`;
  const created = await createDraftCampaign({ name: uniqueName, subject, html });
  const campaignId = created.campaign_id || created.id;
  const activity = (created.campaign_activities || []).find((a) => a.role === 'primary_email') || (created.campaign_activities || [])[0];
  const activityId = activity ? activity.campaign_activity_id : null;
  const ccLink = campaignId
    ? `https://app.constantcontact.com/pages/campaigns/email-details/details/activity/${activityId || campaignId}`
    : null;
  await updateRow(row.id, {
    pipeline: 'Drafted in CC',
    ccCampaignId: campaignId || '',
    ccActivityId: activityId || '',
    ccLink,
    notes: `Draft created ${new Date().toISOString()}`,
  });
  return { rowId: row.id, campaignId, activityId };
}
async function runComposer() {
  if (!DRAFT_ONLY) throw new Error('Composer is draft-only.');
  await getValidAccessToken();
  const rows = await getRowsByStage('Ready to Build');
  const results = { processed: 0, drafts: [], errors: [] };
  for (const row of rows) {
    try {
      const r = await composeOne(row);
      results.processed++;
      results.drafts.push(r);
      console.log(`[composer] drafted "${row.name}" -> ${r.campaignId}`);
    } catch (e) {
      console.error(`[composer] failed "${row.name}": ${e.message}`);
      results.errors.push({ row: row.name, error: e.message });
      try { await updateRow(row.id, { notes: `Compose error: ${e.message}` }); } catch (_) {}
    }
  }
  return results;
}

// ---------------------------------------------------------------------------
// HTTP surface + autonomous loop
// ---------------------------------------------------------------------------
const app = express();
let lastRun = null;
let running = false;
async function tick(trigger) {
  if (running) return { skipped: 'already running' };
  running = true;
  try { lastRun = { at: new Date().toISOString(), trigger, ...(await runComposer()) }; }
  catch (e) { lastRun = { at: new Date().toISOString(), trigger, fatal: e.message }; console.error('[composer] fatal:', e.message); }
  finally { running = false; }
  return lastRun;
}
app.get('/', (req, res) => res.json({ service: 'composer', draftOnly: true, pollMinutes: POLL_MINUTES, lastRun: lastRun || 'none yet' }));
app.get('/healthz', (req, res) => res.json({ ok: true }));
app.get('/run', async (req, res) => res.json(await tick('manual')));

async function initWithRetry(n = 10, d = 3000) {
  for (let i = 1; i <= n; i++) {
    try { await initTokenStore(); console.log('[composer] token store ready'); return; }
    catch (e) { console.warn(`[composer] db init ${i}/${n}: ${e.message}`); if (i < n) await new Promise((r) => setTimeout(r, d)); }
  }
}
app.listen(PORT, () => console.log(`[composer] listening on :${PORT}`));
initWithRetry();
setInterval(() => tick('timer'), POLL_MINUTES * 60 * 1000);
console.log(`[composer] draft-only; polling every ${POLL_MINUTES} min`);
