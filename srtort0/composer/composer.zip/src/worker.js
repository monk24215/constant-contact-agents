// worker.js
// The composer's one job: find calendar rows at "Ready to Build", create a
// draft email campaign in Constant Contact, write the campaign id + link back
// to Notion, and advance the row to "Drafted in CC".
//
// Idempotent-ish: only acts on "Ready to Build" rows, and moves them off that
// stage immediately, so re-runs don't double-create.

import { getRowsByStage, updateRow } from './lib/notion.js';
import { createEmailCampaign, getValidAccessToken } from './lib/index.js';
import { renderEmailHtml } from './lib/template.js';

function physicalAddress() {
  // CAN-SPAM: CC requires a footer address. Pull from env.
  return {
    address_line1: process.env.CC_ADDR_LINE1 || '',
    city: process.env.CC_ADDR_CITY || '',
    state_code: process.env.CC_ADDR_STATE || '',
    postal_code: process.env.CC_ADDR_POSTAL || '',
    country_code: process.env.CC_ADDR_COUNTRY || 'US',
    organization_name: process.env.BRAND_NAME || process.env.CC_ADDR_ORG || '',
  };
}

function senderConfig() {
  const fromEmail = process.env.CC_FROM_EMAIL;
  const fromName = process.env.CC_FROM_NAME || process.env.BRAND_NAME || 'Newsletter';
  if (!fromEmail) {
    throw new Error(
      'CC_FROM_EMAIL is not set. Set it to a VERIFIED sender email in your ' +
        'Constant Contact account, or CC will reject the draft.'
    );
  }
  return { fromEmail, fromName, replyTo: process.env.CC_REPLY_TO || fromEmail };
}

// Process a single row.
async function composeOne(row) {
  const { fromEmail, fromName, replyTo } = senderConfig();
  const subject = row.subject || row.name || 'Newsletter';
  const html = renderEmailHtml({ subject, body: row.body || '', preheader: row.preheader || '' });

  // CC campaign names must be unique; suffix with a timestamp.
  const uniqueName = `${row.name || subject} [${new Date().toISOString().slice(0, 16)}]`;

  const created = await createEmailCampaign({
    name: uniqueName,
    subject,
    fromName,
    fromEmail,
    replyToEmail: replyTo,
    htmlContent: html,
    physicalAddress: physicalAddress(),
  });

  // Extract ids from the CC response shape.
  const campaignId = created.campaign_id || created.id;
  const activity =
    (created.campaign_activities || []).find((a) => a.role === 'primary_email') ||
    (created.campaign_activities || [])[0];
  const activityId = activity ? activity.campaign_activity_id : null;
  const ccLink = campaignId
    ? `https://app.constantcontact.com/pages/campaigns/email-details/details/activity/${activityId || campaignId}`
    : null;

  await updateRow(row.id, {
    pipeline: 'Drafted in CC',
    ccCampaignId: campaignId || '',
    ccActivityId: activityId || '',
    ccLink,
    notes: `Draft created ${new Date().toISOString()}`,
  });

  return { rowId: row.id, campaignId, activityId };
}

// HARD SAFETY WALL: this service creates DRAFTS ONLY. It imports no send or
// schedule function, and this guard enforces that intent. Sending/scheduling
// lives in a separate, human-gated service that does not exist yet.
const DRAFT_ONLY = true;

export async function runComposer() {
  if (!DRAFT_ONLY) {
    throw new Error('Composer is draft-only and must never send or schedule.');
  }
  // Fail fast with a clear message if config is missing.
  senderConfig();
  await getValidAccessToken(); // verifies token chain is alive

  const rows = await getRowsByStage('Ready to Build');
  const results = { processed: 0, errors: [], drafts: [] };

  for (const row of rows) {
    try {
      const r = await composeOne(row);
      results.processed++;
      results.drafts.push(r);
      console.log(`[composer] drafted "${row.name}" -> campaign ${r.campaignId}`);
    } catch (e) {
      console.error(`[composer] failed on "${row.name}": ${e.message}`);
      results.errors.push({ row: row.name, error: e.message });
      // Park the row with an error note so it doesn't silently retry forever.
      try {
        await updateRow(row.id, { notes: `Compose error: ${e.message}`.slice(0, 1900) });
      } catch (_) {}
    }
  }

  return results;
}
